<!-- 



<html>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<form method="post" name="present-absent">
	       <tr>
					<td height="25" colspan="4" class="bgcolor_02">&nbsp;&nbsp;<span class="admin">Class Report Prsent and Absent Student</span></td>
				  </tr>
   <tr >
   <td width="21%" class="narmal">
   Select Class:
   </td>

    <td width="40%" class="narmal">
       <select name="class">
       		  <option value=""> 1B1
     </option>
      </select>
</td>

<td width="21%" class="narmal">
Select Class:
</td>
<td width="40%" class="narmal">
     <select name="academic_year">
        <option value=""> 2015-2014
     </option>


     </select>
</td>
</tr>

</form>
</table>

</body>

</html>

 -->