<?php 
        sm_registerglobal('pid', 'action', 'emsg');
		/**
* Only Student or schoool staff  can be allowed to access this page
*/ 
checkuserinlogin();
?>													 